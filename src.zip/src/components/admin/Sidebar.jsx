import { NavLink } from "react-router-dom";

const Sidebar = () => {
	const menu = [
		{ name: "Dashboard", path: "/admin" },
		{ name: "Movies", path: "/admin/movies" },
		{ name: "Orders", path: "/admin/orders" },
		{ name: "Customers", path: "/admin/customers" },
		{ name: "Rooms", path: "/admin/rooms" },
		{ name: "Showtimes", path: "/admin/showtimes" },
		{ name: "Revenue", path: "/admin/revenue" },
	];


	return (
		<aside className="w-64 bg-zinc-900 text-white p-4">
			<h2 className="text-xl font-bold mb-6">Cinema Admin</h2>
			<nav className="flex flex-col gap-2">
				{menu.map((item) => (
					<NavLink
						key={item.path}
						to={item.path}
						className={({ isActive }) =>
							`p-3 rounded-lg ${
								isActive ? "bg-blue-600" : "hover:bg-zinc-700"
							}`
						}
					>
						{item.name}
					</NavLink>
				))}
			</nav>
		</aside>
	);
};

export default Sidebar;
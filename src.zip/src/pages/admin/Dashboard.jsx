const Dashboard = () => {
  return (
    <div>
      <h1>Admin Dashboard</h1>

      <p>Welcome to cinema management system</p>
    </div>
  );
};

export default Dashboard;